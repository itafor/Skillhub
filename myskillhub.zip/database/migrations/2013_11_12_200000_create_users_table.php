<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->string('sex');
            $table->string('phone');
            $table->string('address');
            $table->string('role');
            $table->string('photo')->nullable();
            $table->string('mycv')->nullable();
            $table->string('state')->nullable();
            $table->string('lga')->nullable();
            $table->string('qualification')->nullable();
            $table->text('about')->nullable();
            $table->string('status')->default('Available');
            $table->string('email')->unique();
            $table->string('token')->nullable();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
