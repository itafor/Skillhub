<!-- Gift Card Section -->
  <section id="gift-cards" class="section bg-light">
    <div class="container">
      <div class="gift-cards">
        <div>
          <img src="img/cards.png" alt="">
        </div>
        <div>
          <h2>TESTIMONIES</h2>
          <p>
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque expedita tempore quasi omnis a aut et totam illo fuga accusamus
            dolorum vero, ut harum consectetur. Minima molestias officiis culpa non sed dicta itaque. Et aliquam illo obcaecati
            molestias veritatis porro.
          </p>
          <p>Already have an Orange MyTunes Music Gift Card?</p>
          <hr>
          <a href="#" class="text-secondary">
            <i class="fa fa-chevron-right"></i> See More
          </a>
        </div>
      </div>
    </div>
  </section>