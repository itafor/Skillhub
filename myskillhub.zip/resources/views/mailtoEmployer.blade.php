<!DOCTYPE html>
<html>
<head>
	<title>TEST</title>
</head>
<body>
	
<p>
Dear {{ $name }} , <br>

Thanks for requesting for job seekers in our platform, <br>
 your request has been received and is been processed,<br>
 we will get back to you as soon as possible. <br>

 Thanks <br><br>

  Myskillhub <br>
  07065907948 <br>
  itaforfrancis@gmail.com<br>
</p>
<div><a href="http://localhost:8000/viewSpecificEmpReq/{{$requestID}}">See your request status </a></div>
</body>
</html>