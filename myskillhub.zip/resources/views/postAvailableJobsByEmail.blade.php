<!DOCTYPE html>
<html>
<head>
	<title>TEST</title>
</head>
<body>
	
<p>
Dear {{ $name }} , <br><br>


<b>Available job as at now</b> <br><br>
 
  <br> {{$description}}<br><br>


  <br> {{$jobs}}<br><br>



 Thanks <br><br>

  Myskillhub <br>
  07065907948 <br>
  itaforfrancis@gmail.com<br>
</p>
</body>
</html>