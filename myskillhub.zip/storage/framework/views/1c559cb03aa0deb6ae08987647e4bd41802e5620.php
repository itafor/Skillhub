<?php $__env->startSection('content'); ?>
<?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

 <!-- breadcrum start -->

<section id="breadcrum">
  <div class="container">
      <?php echo $__env->make('master.remainder', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
</section>
        <!-- breadcrum ends -->

  <!-- Begin page content -->
<section id="main">
  <div class="container">
    <div class="row">
  <!-- Begin SIDE BAR -->
      <?php echo $__env->make('master.sideMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- END SIDE BAR -->

  <!-- Begin main content -->

       <div class="col-md-9">

<div class="card">
           <h5 class="card-header main-color-bg" style="color: #fff;">UPDATE PROFILE</h5>
        <div class="card-body">

        
      <!--POST SKILL FORM STARTS-->
<form  action="<?php echo e(route('updateProfile')); ?>" method="POST" enctype="multipart/form-data">
  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
  
   
  <div class="form-row">
    <div class="col-md-6 mb-4">
      <label for="validationCustom01">Full name</label>
      <input type="text" name="name" class="form-control" value="<?php echo e($userProfile->name); ?>" required>
          </div>
    <div class="col-md-6 mb-4">
      <label for="validationCustom02">Gender</label>
      <input type="text" name="sex" class="form-control" value="<?php echo e($userProfile->sex); ?>"  required>
    </div>
  </div>
  <div class="form-row">
    <div class="col-md-6 mb-3">
      <label for="validationCustom03">Residential Address</label>
     <textarea name="address" class="form-control" ><?php echo e($userProfile->address); ?></textarea>
    </div>
    <div class="col-md-6 mb-3">
      <label for="validationCustom04">Email Address</label>
      <input type="text" class="form-control" name="email" value="<?php echo e($userProfile->email); ?>" readonly="readonly" >
    </div>
  </div>

   
<div class="form-row">
<div class="col-md-6 mb-4">
    <label>State</label>
<select name="state" id="state" class="form-control input-lg dynamic"
data-dependent="lga" style=" height:60px;">
<option value="<?php echo e($userProfile->state); ?> "><?php echo e($userProfile->state); ?></option>
<?php $__currentLoopData = $state_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($state->state); ?>"><?php echo e($state->state); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>

  <div class="col-md-6 mb-4">
    <label>LGA</label>
<select name="lga" id="lga" class="form-control input-lg dynamic" style=" height:60px;">
<option value="<?php echo e($userProfile->lga); ?>"><?php echo e($userProfile->lga); ?></option>
</select>
</div>
</div>

<div class="form-row">
  <div class="col-md-6 mb-4">
      <label for="validationCustom02">Select Highest   Qualification</label>
     <select name="qualification" class="form-control" required="required">
       <option value="<?php echo e($userProfile->qualification); ?>"><?php echo e($userProfile->qualification); ?> </option>
       <option value="None">None</option>
       <option value="Primary">Primary</option>
       <option value="Secondary">Secondary</option>
       <option value="Tertially">Tertially</option>
     </select>
    </div>
     <div class="col-md-6 mb-3">
      <label for="validationCustom04">Phone</label>
      <input type="text" class="form-control" name="phone" value="<?php echo e($userProfile->phone); ?>" readonly="readonly" >
    </div>
</div>

<div class="form-row">
   <div class="col-md-6 mb-4">
      <label for="validationCustom02">Employment status</label>
     <select name="status" class="form-control" required="required">
       <option value="<?php echo e($userProfile->status); ?>"><?php echo e($userProfile->status); ?> </option>
       <option value="Available">Available</option>
       <option value="Hired">Hired</option>
     </select>
    </div>
</div>
  <button class="btn btn-primary" type="submit">Update Profile</button>
</form>

</div>
</div>


        
 
      </div><!-- End main content -->

    </div>
  </div>
</section>
    <!-- end page content -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>