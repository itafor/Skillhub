<?php $__env->startSection('content'); ?>
<?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
 <!-- breadcrum start -->

<section id="breadcrum">
  <div class="container">
      <?php echo $__env->make('master.remainder', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
</section>
        <!-- breadcrum ends -->

  <!-- Begin page content -->
<section id="main">
  <div class="container">
    <div class="row">
  <!-- Begin SIDE BAR -->
   <?php echo $__env->make('master.sideMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
     <!-- END SIDE BAR -->

  <!-- Begin main content -->
       <div class="col-md-9">
      <?php echo $__env->make('master.check', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

   <?php echo $__env->make('master.dashboardList', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
  </div>
</section>
    <!-- end page content -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>