<?php $__env->startSection('content'); ?>
<?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <!-- breadcrum start -->

<section id="breadcrum">
  <div class="container">
    <ol class="breadcrum">
      <a href="">Dashboard</a>
    </ol>
  </div>
</section>
        <!-- breadcrum ends -->

  <!-- Begin page content -->
<section id="main">
  <div class="container">
    <div class="row">
  <!-- Begin SIDE BAR -->
      <?php echo $__env->make('master.sideMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- END SIDE BAR -->

  <!-- Begin main content -->
  <div class="col-md-9">
        <div class="card" style="width: 18rem;">
<h5 class="card-header main-color-bg" style="color: #fff;">Applicant Requested</h5>

  <img class="card-img-top" src="/upload/<?php echo e($users->photo); ?>" alt="Card image cap">
  <div class="card-body">
    <p class="card-text">
    <?php echo e($users->about); ?>

    </p>
  </div>
  <ul class="list-group list-group-flush">
    <li class="list-group-item"><h2> <?php echo e($users->name); ?></h2></li>
    <li class="list-group-item"><i class="fa fa-intersex"></i>  <?php echo e($users->sex); ?></li>
    <li class="list-group-item"><i class="fa fa-phone"></i>  <?php echo e($users->phone); ?></li>
    <li class="list-group-item"><i class="fa fa-envelope"></i>  <?php echo e($users->email); ?></li>
    <li class="list-group-item"><i class="fa fa-map-marker"></i>  <?php echo e($users->state); ?></li>
  </ul>
  <div class="card-body">
  <?php if(count($users->imageproofs)): ?>
    <?php $__currentLoopData = $users->imageproofs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="/checkimageproof/<?php echo e($image->user_id == '' ? '' : $image->user_id); ?>" target="_blank">
 <?php echo e($image->user_id == '' ? '' : 'Picture Proof'); ?></a></span><br>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(count($users->videos)): ?>
    <?php $__currentLoopData = $users->videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="/checkvideoproof/<?php echo e($video->user_id == '' ? '' : $video->user_id); ?>" target="_blank">
 <?php echo e($video->user_id == '' ? '' : 'Video Proof'); ?></a></span><br>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>

  <?php if(count($users->onlineproofs)): ?>
  <?php $__currentLoopData = $users->onlineproofs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $online): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="/checkonlineproof/<?php echo e($online->user_id == '' ? '' : $online->user_id); ?>" target="_blank">
 <?php echo e($online->user_id == '' ? '' : 'Website URL'); ?></a></span><br>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
  </div>

        
 
      </div>

    </div>
  </div>
</section>
    <!-- end page content -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>