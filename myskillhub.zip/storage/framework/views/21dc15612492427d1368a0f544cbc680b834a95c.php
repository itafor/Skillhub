<?php $__env->startSection('content'); ?>
<?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
 <!-- breadcrum start -->

<section id="breadcrum">
  <div class="container">
      <?php echo $__env->make('master.remainder', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
</section>
        <!-- breadcrum ends -->

   <!-- Begin page content -->
<section id="main">
  <div class="container">
    <div class="row">
  <!-- Begin SIDE BAR -->
     <?php echo $__env->make('master.sideMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- END SIDE BAR -->

  <!-- Begin main content -->



  

       <div class="col-md-9">

<div class="card">
           <h5 class="card-header main-color-bg" style="color: #fff;">UPDATE REQUEST</h5>
        <div class="card-body">


      <!--Request for job seekers FORM   -->
<form novalidate method="POST" action="<?php echo e(route('updateRequestedJobseekers',$editSpecificEmpReq->id)); ?>">
  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
  <div class="form-row">
    <div class="col-md-6 mb-4">
      <label for="validationCustom01">Required Skills and Competencies</label>
      <input type="text" class="form-control" name="skillReq"  value="<?php echo e($editSpecificEmpReq->skillReq); ?>" required>
    </div>
    <div class="col-md-6 mb-4">
      <label for="validationCustom02">Company Name</label>
      <input type="text" class="form-control" name="compName" value="<?php echo e($editSpecificEmpReq->compName); ?>">
    </div>
  </div>
  <div class="form-row">
    <div class="col-md-6 mb-3">
      <label for="validationCustom03">Gender of Jobseekers</label>
     <select name="gender" class="form-control">
       <option value="<?php echo e($editSpecificEmpReq->sex); ?>"><?php echo e($editSpecificEmpReq->gender); ?></option>
       <option value="Only Male">Only Male</option>
       <option value="Only Female">Only Female</option>
       <option value="Male & Female">Male & Female</option>
     </select>
      
    </div>
    <div class="col-md-6 mb-3">
      <label for="validationCustom04">Company's address or Job's location</label>
      <input type="text" class="form-control"  name="companyAddress" value="<?php echo e($editSpecificEmpReq->companyAddress); ?>" >
    </div>
  </div>

    <div class="form-row">
    <div class="col-md-6 mb-3">
      <label for="validationCustom03">Contact phone</label>
      <input type="text" class="form-control" value="<?php echo e($editSpecificEmpReq->compPhone); ?>" name="compPhone" >
    
      
    </div>
    <div class="col-md-6 mb-3">
      <label for="validationCustom04">Email Address</label>
      <input type="text" class="form-control" name="compEmail" value="<?php echo e($editSpecificEmpReq->compEmail); ?>" >
    </div>
  </div>
<div class="form-row">
<div class="col-md-6 mb-4">
    <label>State</label>
<select name="state" id="state" class="form-control input-lg dynamic"
data-dependent="lga" style=" height:60px;">
<option value="<?php echo e($editSpecificEmpReq->state); ?> "><?php echo e($editSpecificEmpReq->state); ?></option>
<?php $__currentLoopData = $state_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($state->state); ?>"><?php echo e($state->state); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>

  <div class="col-md-6 mb-4">
    <label>LGA</label>
<select name="lga" id="lga" class="form-control input-lg dynamic" style=" height:60px;">
<option value="<?php echo e($editSpecificEmpReq->lga); ?>"><?php echo e($editSpecificEmpReq->lga); ?></option>
</select>
</div>
</div>


  <div class="form-row">
  <div class="col-md-6 mb-4">
    <label>Job description</label>
    <textarea name="jobdescription" class="form-control" rows="5" required="required"><?php echo e($editSpecificEmpReq->jobdescription); ?></textarea>
  </div>

   <div class="col-md-6 mb-4">
    <label>Job Requirements</label>
    <textarea name="jobrequirement" class="form-control" rows="5"><?php echo e($editSpecificEmpReq->jobrequirement); ?></textarea>
  </div>
  </div>

  <div class="form-row">
  <div class="col-md-6 mb-4">
    <label>Key Responsibilities and Accountabilities</label>
    <textarea name="jobresponsibility" class="form-control" rows="5"><?php echo e($editSpecificEmpReq->jobresponsibility); ?></textarea>
  </div>

   <div class="col-md-6 mb-4">
    <label>EXPERIENCE LEVEL</label>
    <select name="jobExpLevel" class="form-control">
       <option value="<?php echo e($editSpecificEmpReq->jobExpLevel); ?>"><?php echo e($editSpecificEmpReq->jobExpLevel); ?></option>
      
      <option value="Junior Level">Junior Level</option>
      <option value="Mid Level">Mid Level</option>
      <option value="Senior Level">Senior Level</option>
    </select>
  </div>
  </div>
  <div class="form-row">
  <div class="col-md-6 mb-4">
    <label>Recruitment deadline(yyy/mm/dd, time)</label>
    <input type="text" name="recruitDeadline" class="form-control" value="<?php echo e($editSpecificEmpReq->recruitDeadline); ?>" id="datetimepicker">
  </div>
  <div class="col-md-6 mb-4">
      <label for="validationCustom02">Number of applicants needed</label>
      <input type="text" class="form-control" name="noOfAplicant" value="<?php echo e($editSpecificEmpReq->noOfAplicant); ?>" required>
    </div>
  </div>

  <div class="form-row" >
  <div class="col-md-12 mb-4">
    <label for="validationCustom02">Job Title</label>
      <input type="text" class="form-control" name="jobTitle" value="<?php echo e($editSpecificEmpReq->jobTitle); ?>"  required>
    </div>
    </div>
  <button class="btn btn-primary" type="submit">Update Request</button>
</form>
</div>
</div>

 
      </div><!-- End main content -->

    </div>
  </div>
</section>
    <!-- end page content -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>