<?php $__env->startSection('content'); ?>
<?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
 <!-- breadcrum start -->
<section id="breadcrum">
  <div class="container">
      <?php echo $__env->make('master.remainder', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
</section>
        <!-- breadcrum ends -->

  <!-- Begin page content -->
<section id="main">
  <div class="container">
    <div class="row">
  <!-- Begin SIDE BAR -->
      <?php echo $__env->make('master.sideMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- END SIDE BAR -->

  <!-- Begin main content -->
       <div class="col-md-9">
                   <div id="message"></div>
      
 <div class="card">
           <h5 class="card-header main-color-bg" style="color: #fff;">All JOBS POSTED BY EMPLOYERS</h5>
        <div class="card-body">
                  <?php if(count($employerReq) > 0): ?>
               <table class="table table-striped table-hover table-responsive" >
                 <tr>
                   <th>Job Title</th>
                   <th>Date Posted</th>
                   <th>Applicants</th>
                   <th>Status</th>
                   <th>View</th>
                   <th>Update</th>
                   <th>Delete</th>
                 <?= auth::user()->role == 'Admin' ?'<th>ACTION</th>':''?>
                 </tr>
                  <?php $__currentLoopData = $employerReq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                 <tr>
                   <td><?php echo e($req->jobTitle); ?></td>
                   <td><?php echo e(Carbon\carbon::createFromTimestamp(strtotime($req->created_at))->diffForHumans()); ?></td>
              <td> <a href="applicationsToThisJob/<?php echo e($req->id); ?>">Applicants</a></td>

                  <td id="<?php echo e($req->status); ?>"><?php echo e($req->status); ?></td>
              <td> <a href="viewSpecificEmpReq/<?php echo e($req->id); ?>"><i class="fa fa-eye text-primary"></i></a></td>
              <td> <a href="editSpecificEmpReq/<?php echo e($req->id); ?>"><i class="fa fa-edit text-success"></i></a></td>
              <td> <a href="deleteSpecificEmpReq/<?php echo e($req->id); ?>" onclick="return confirm('Are you sure to delete this Application request?');"><i class="fa fa-remove text-danger"></i></a></td> 

              <?php if($req->status === "Pending"): ?>
           <td id="approve"> <a href="approveSpecificEmpReq/<?php echo e(auth::user()->role == 'Admin' ? $req->id : ''); ?>" onclick="return confirm('You are about to approve this Application request. Are you sure?');" class="text-success"> <?php echo e(auth::user()->role == 'Admin' ? 'Approve' : ''); ?></a></td>
           <?php else: ?>
          <td id="disapprove"> <a href="disapproveSpecificEmpReq/<?php echo e(auth::user()->role == 'Admin' ? $req->id : ''); ?>" onclick="return confirm('You are about to disapprove this Application request. Are you sure?');" class="text-danger"> <?php echo e(auth::user()->role == 'Admin' ? 'Disapprove' : ''); ?></a></td>
            <?php endif; ?>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   <?php else: ?>
                   <h4>No Applicant Request Found</h4>
                   <?php endif; ?>
                 </tr>
               </table> 

        </div>
</div>  <!-- Latest Users ends-->
               <?php echo e($employerReq->links()); ?>


      </div><!-- End main content -->

    </div>
  </div>
</section>
    <!-- end page content -->

<script type="text/javascript">
  //Ananimious self invoking function
  (function() {
    
     // declare variables and objects properties
    let pending = document.getElementById('Pending');

    let approve = document.getElementById('Approved');

    
    pending.style.color = 'Brown';
    approve.style.color = 'Green';

    
   
  }());
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>