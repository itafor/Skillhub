<?php $__env->startSection('content'); ?>
<?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <!-- breadcrum start -->

<section id="breadcrum">
  <div class="container">
      <?php echo $__env->make('master.remainder', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
</section>
        <!-- breadcrum ends -->

  <!-- Begin page content -->
<section id="main">
  <div class="container">
    <div class="row">
  <!-- Begin SIDE BAR -->
      <?php echo $__env->make('master.sideMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- END SIDE BAR -->

  <!-- Begin main content -->

       <div class="col-md-9">

<div class="card">
           <h5 class="card-header main-color-bg" style="color: #fff;">Add Image Proof (Maximum video size allowed is 4MB)</h5>
        <div class="card-body">

        
      <!--POST SKILL FORM STARTS-->
<form  action="<?php echo e(route('storeVideoProof')); ?>" method="POST" enctype="multipart/form-data">
  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
   <div class="form-row">
     <div class="col-md-6 mb-3">
      <label for="validationCustom04">Video Name</label>
      <input type="text" class="form-control" name="videoname" >
    </div>
    <div class="col-md-6 mb-3">
      <label for="validationCustom04">Video Proof</label>
      <input type="file" class="form-control" name="videoProof" >
    </div>
  </div>
  <button class="btn btn-primary" type="submit">Add Video Proof</button>
</form>
</div>
</div>
 
</div><!-- End main content -->
</div>
  </div>
</section>
    <!-- end page content -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>