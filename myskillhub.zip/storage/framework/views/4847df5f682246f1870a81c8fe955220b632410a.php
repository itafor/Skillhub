<?php $__env->startSection('content'); ?>
<?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

 <!-- breadcrum start -->

  <!-- Begin page content -->
<section id="main">
  <div class="container">
    <div class="row">
  <!-- Begin SIDE BAR -->
    
  <!-- END SIDE BAR -->

  <!-- Begin main content -->

<div class="col-md-12">

<div class="card">
           <h5 class="card-header main-color-bg" style="color: #fff;">Fill this form to hire <?php echo e($userID->name); ?></h5>
        <div class="card-body">


      <!--POST SKILL FORM STARTS-->
<form  action="<?php echo e(route('saveRequest')); ?>" method="POST">
  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
  <div class="form-row">
    <input type="hidden"   name="user_id"   value="<?php echo e($userID->id); ?>">
    <div class="col-md-12 mb-4">
      <label for="validationCustom01">Name</label>
      <input type="text" name="empName" class="form-control" placeholder="Please type your name">
     
    </div>
   </div>
  <div class="form-row">
    <div class="col-md-12 mb-4">
      <label for="validationCustom02">Phone number</label>
      <input type="text" name="empphone" class="form-control" placeholder="please type your phone number"  required>
     
    </div>
  </div>
  <div class="form-row">
   
    <div class="col-md-12 mb-3">
      <label>Email Address</label>
    <input type="text" name="empEmail" class="form-control">
    
    </div>
  </div>

  <div class="form-row">
    <div class="col-md-12 mb-3">
      <label>Select required skills</label>
        
        <select name="skills[]" class="form-control chzn-select" multiple="true"  >
          <?php $__currentLoopData = $myskills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($skill->name); ?>"><?php echo e($skill->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
  </div>

  <div class="form-row">
    <div class="col-md-12 mb-3">
      <label>Describe your needs</label>
    <textarea name="Empdescription" class="form-control" cols="10" rows="5" placeholder="Please, Briefly describe what you want from this applicant"></textarea>
    
    </div>
  </div>

  <button class="btn btn-primary" type="submit">Submit Request</button>
</form>
</div>
</div>

        
 
      </div><!-- End main content -->

    </div>
  </div>
</section>
    <!-- end page content -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>