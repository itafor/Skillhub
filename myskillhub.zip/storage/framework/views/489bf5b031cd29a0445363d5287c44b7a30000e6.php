<?php $__env->startSection('content'); ?>
<?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

 <!-- breadcrum start -->
<section id="breadcrum">
  <div class="container">
      <?php echo $__env->make('master.remainder', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
</section>
        <!-- breadcrum ends -->

  <!-- Begin page content -->
<section id="main">
  <div class="container">
    <div class="row">
  <!-- Begin SIDE BAR -->
      <?php echo $__env->make('master.sideMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- END SIDE BAR -->

  <!-- Begin main content -->
       <div class="col-md-9">
        <!-- Latest Users start-->
 <div class="card">
           <h5 class="card-header main-color-bg" style="color: #fff;">REQUESTED APPLICANTS FROM EMPLOYERS</h5>
        <div class="card-body">
               <table class="table table-bordered table-hover table-responsive" >
                 <tr>
                   <th>NAME</th>
                   <th>EMAIL</th>
                   <th>PHONE</th>
                   <th>SKILLS NEEDED</th>
                   <th>DESCRIPTION</th>
                   <th>APPLICANT REQUESTED</th>
                   <th>ACTION</th>
                 </tr>
                  <?php $__currentLoopData = $requestedApplicants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                 <tr>
                   <td><?php echo e($request->empName); ?></td>
                   <td><?php echo e($request->empEmail); ?></td>
                   <td><?php echo e($request->empphone); ?></td>
                   <td><p><?php echo e($request->skills); ?></p></td>
                   <td><?php echo e($request->Empdescription); ?></td>
                   <td><a href="applicanttohire/<?php echo e($request->id); ?>">View</a></td>
                   <td><a href="deleteReq/<?php echo e($request->id); ?>" onclick="return confirm('Are you sure to delete this Employer request?');"><i class="fa fa-remove text-danger"></i></a></td>
                 </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

               </table> 

        </div>
</div>  <!-- Latest Users ends-->
      </div><!-- End main content -->

    </div>
  </div>
</section>
    <!-- end page content -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>