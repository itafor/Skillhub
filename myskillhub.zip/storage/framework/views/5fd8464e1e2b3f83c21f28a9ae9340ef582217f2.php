<?php $__env->startSection('content'); ?>
<?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
 <!-- breadcrum start -->

<section id="breadcrum">
  <div class="container">
    <ol class="breadcrum">
      <?php if(auth::user()): ?>
      <a href="/admindashboard" style="width: 100px; height:70px; font-size: 20px; border-radius: 5px;  color: #ffffff;">Home</a>
      <?php endif; ?>
    </ol>
  </div>
</section>
        <!-- breadcrum ends -->

  <!-- Begin page content -->
<section id="main">

  <div class="container">
    <div class="row">

  <!-- Begin main content -->
       <div class="col-md-12">
        <!-- site overview -->
           <div class="card">
           <h5 class="card-header main-color-bg" style="color: #fff;"> 
           <?= auth::user() ? 'My Profile' : 'Applicant details' ?>
         </h5>
        <div class="card-body ">
                
<div class="col-md-4 pull-left jobseekerinfo ">
<p class="text-center"><b><i class="fa fa-asterisk info"></i>Info</b> </p>
<div class="image-container">
<img src="/upload/<?php echo e($users->photo == '' ? 'female.png' : $users->photo); ?>" class="profile-image">
<div class="title">
<h2><?php echo e($users->name); ?></h2>
</div>
</div>
<div class="main-container">
<p><i class="fa fa-phone info"></i> <?php echo e($users->phone); ?> </p>
<p><i class="fa fa-envelope info"></i> <?php echo e($users->email); ?> </p>
<p><i class="fa fa-intersex info"></i> <?php echo e($users->sex); ?> </p>
<?php if($users->state): ?>
 <p><i class="fa fa-map-marker info"></i> <?php echo e($users->state); ?></p>
  <?php endif; ?>
<?php if($users->mycv): ?>
 <p><i class="fa fa-download info"></i><a href="/upload/<?php echo e($users->mycv); ?>" download="<?php echo e($users->mycv); ?>">CV</a> </p>
 <?php endif; ?>
 <hr>
</div>
</div>

<div class="col-md-8 pull-right text-center">
 <p><b><i class="fa fa-asterisk info"></i>Skills</b> </p>
<hr>
<div class="main-container">
  <?php if(count($users->skills) >=1): ?>
  <table width="100%" class="table table-bordered">
    <tr>
      <th>Skill</th>
      <th> Experience Level</th>
    </tr>
    <?php $__currentLoopData = $users->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <tr>
      <td><span style="font-family: roboto; font-size: 18px;"> <?php echo e($skill->name); ?> </span></td>
      <td>   <div class="skill-bar">
        <div class="progress-bar" style="width: <?php echo e($skill->skill_level); ?>%;"><?php echo e($skill->skill_level); ?>%</div>
     </div> </div></td>
    </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  <?php else: ?>
  <p>No skill to display</p>
<?php endif; ?>

<?php if(count($users->imageproofs) >= 1 || count($users->videos) >= 1 || count($users->onlineproofs) >= 1): ?>
<p><b><i class="fa fa-asterisk info"></i>Skill's Proofs</b> </p>
<hr>
<table width="100%">
  <tr>
<?php endif; ?>
 <ul> 
    <td>
      <?php $__currentLoopData = $users->imageproofs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
<a href="/checkimageproof/<?php echo e($image->user_id == '' ? '' : $image->user_id); ?>" target="_blank">
 <?php echo e($image->user_id == '' ? '' : 'Picture Proof'); ?></a></span><br>
</li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </td>
    <td>

  <?php $__currentLoopData = $users->onlineproofs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $online): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
<a href="/checkonlineproof/<?php echo e($online->user_id == '' ? '' : $online->user_id); ?>" target="_blank">
 <?php echo e($online->user_id == '' ? '' : 'Website URL'); ?></a></span><br>
</li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </td>
    <td>
      
  <?php $__currentLoopData = $users->videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
<a href="/checkvideoproof/<?php echo e($video->user_id == '' ? '' : $video->user_id); ?>" target="_blank">
 <?php echo e($video->user_id == '' ? '' : 'Video Proof'); ?></a></span><br>
</li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </td>
</ul>
 </tr>
</table>
<hr>
   <span><i class="fa fa"></i>STATUS: <b><?php echo e($users->status); ?></b></span><br>
<?php $userId = $users->id; 
     $cryptId = Crypt::encrypt($userId);       
?>
<div class="hireMe btn btn-primary"><a href="/requestUser/<?php echo e($cryptId); ?>"><?php echo e($users->status == 'Available'? 'HIRE ME' : 'HIRED'); ?> </a>
   </div>
   <hr>
               </div>
        </div>
    </div>
</div><!-- End main content -->

</div>

</div>
  
</section>
    <!-- end page content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>