

<!DOCTYPE html>
<html>
<head>
	<title>TEST</title>
</head>
<body>
	
<h1 style="color: #fff;">Hi, <?php echo e($name); ?></h1>
<h4>Employer Name <?php echo e($empName); ?></h4>
<h4>Employer Phone <?php echo e($empphone); ?></h4>
<h4>Employer Email <?php echo e($empEmail); ?></h4>



<p>
	<?php $userId = $userID; 
     $cryptId = Crypt::encrypt($userId);       
?>
<h2>Emplyer description</h2>
<?php echo e($Empdescription); ?></p>
<div><a href="http://localhost:8000/jobseekerinfo/<?php echo e($cryptId); ?>">See the applicant this employer want to hire</a></div>
</body>
</html>