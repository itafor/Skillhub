<?php $__env->startSection('content'); ?>
<?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

 <!-- breadcrum start -->

<section id="breadcrum">
  <div class="container">
      <?php echo $__env->make('master.remainder', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
</section>
        <!-- breadcrum ends -->

  <!-- Begin page content -->
<section id="main">
  <div class="container">
    <div class="row">
  <!-- Begin SIDE BAR -->
      <?php echo $__env->make('master.sideMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- END SIDE BAR -->

  <!-- Begin main content -->
       <div class="col-md-9">
      
 <div class="card">
           <h5 class="card-header main-color-bg" style="color: #fff;">Job Details  
            <?php if(auth::user()->role == 'Applicant'): ?>
        <a href="/applyToThisJob/<?php echo e($viewSpecificEmpReq->id); ?>" onclick="return validate()">Apply Now</a>
           <?php endif; ?>

      <label for="remember">      
    <input id="remember" name="remember" type="checkbox"  />
    My skills matched the job requirement</label> 
</h5>
        <div class="card-body">
<div class="card-row">
  <div class="col-md-4 pull-left" >
      <small style="font-size:16;"><b>Company Name</b></small>         
  <p class="content"><?php echo e($viewSpecificEmpReq->compName); ?></p>

  <small style="font-size:16;"><b>Job Title</b></small>         
  <p class="content"><?php echo e($viewSpecificEmpReq->jobTitle); ?></p>

<small style="font-size:16;"><b>Company Phone</b></small>         
  <p class="content"><?php echo e($viewSpecificEmpReq->compPhone); ?></p>

<small style="font-size:16;"><b>Company Email</b></small>         
  <p class="content"><?php echo e($viewSpecificEmpReq->compEmail); ?></p>

<small style="font-size:16;"><b>Company Address</b></small>         
  <p class="content"><?php echo e($viewSpecificEmpReq->companyAddress); ?></p>
  

<small style="font-size:16;"><b>Company Location</b></small>         
  <p class="content"><?php echo e($viewSpecificEmpReq->state); ?></p>

  <small style="font-size:16;"><b> Applicants needed</b></small>         
  <p class="content"><?php echo e($viewSpecificEmpReq->noOfAplicant); ?></p>

  <small style="font-size:16;"><b>Request Status</b></small>         
  <p class="content"><?php echo e($viewSpecificEmpReq->status); ?></p>

<small style="font-size:16;"><b>Date Posted</b></small>         
<p> <?php echo e(Carbon\carbon::createFromTimestamp(strtotime($viewSpecificEmpReq->created_at))->diffForHumans()); ?></p>

<small style="font-size:16;"><b>Recruitment End date</b></small>

<p> <?php echo e(Carbon\carbon::createFromTimestamp(strtotime($viewSpecificEmpReq->recruitDeadline))->diffForHumans()); ?></p>         
  </div>

  <div class="col-md-6 pull-right" style="border-left: 1px solid #333;">
    <small style="font-size:16;"><b>Required Skills</b></small>         
  <p class="content"><?php echo e($viewSpecificEmpReq->skillReq); ?></p>

  <small style="font-size:16;"><b>Job description</b></small>         
  <p class="content"><?php echo e($viewSpecificEmpReq->jobdescription); ?></p>

  <small style="font-size:16;"><b>Job Requirements</b></small>         
  <p class="content"><?php echo e($viewSpecificEmpReq->jobrequirement); ?></p>

  <small style="font-size:16;"><b>Key Responsibilities</b></small>         
  <p class="content"><?php echo e($viewSpecificEmpReq->jobresponsibility); ?></p>

<small style="font-size:16;"><b>EXPERIENCE LEVEL</b></small>         
  <p class="content"><?php echo e($viewSpecificEmpReq->jobExpLevel); ?></p>
 

<small style="font-size:30;"><b>STATUS</b></small>         
  <p class="content" style="font-size:30;"><?php echo e($viewSpecificEmpReq->expired); ?></p>
  </div>
       
</div>
        </div>
<div class="card-body">
<?php if(auth::user()->role == 'Admin'): ?>
<a href="/shareJobToApplicants/<?php echo e($viewSpecificEmpReq->id); ?> " onclick="return confirm('Do you really want to share this job to applicants?')">Share this job to Applicants</a>
<?php endif; ?>

<?php if(auth::user()->role == 'Applicant'): ?>
<a href="/applyToThisJob/<?php echo e($viewSpecificEmpReq->id); ?>" onclick="return validate()">Apply Now</a>
<?php endif; ?>

<?php if(auth::user()->role == 'Employer'): ?>
<a href="/editSpecificEmpReq/<?php echo e($viewSpecificEmpReq->id); ?>">EDIT REQUEST</a>

<a href="/deleteSpecificEmpReq/<?php echo e($viewSpecificEmpReq->id); ?>" onclick="return confirm('Are you sure you want to delete this request?');" class="text-danger">DELETE REQUEST</a>

<?php endif; ?>

</div>
</div>  <!-- Latest Users ends-->
      </div><!-- End main content -->

    </div>
  </div>
</section>
    <!-- end page content -->
<script type="text/javascript">
    function validate(e) {
        if (document.getElementById('remember').checked) {
            return true;
        } else {
            alert("You must accept that your skills matched the job Requirements by checking the checked button above.");
return false;
        }
    }
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>