<!DOCTYPE html>
<html>
<head>
	<title>TEST</title>
</head>
<body>
	
<p>
Dear <?php echo e($name); ?> , <br><br>


<b>Available job as at now</b> <br><br>
 
 <b>Job Title  </b> : <br> <?php echo e($jobTitle); ?><br><br>
 <b>Skills Required  </b> : <br> <?php echo e($skillsReq); ?><br><br>
 <b>Job Requirements </b> : <br> <?php echo e($jobReq); ?><br><br>
 <b>Responsibilities </b> : <br> <?php echo e($jobResp); ?><br><br>

<div><a href="http://localhost:8000/viewSpecificEmpReq/<?php echo e($jobID); ?>"> View more to apply </a></div><br><br>
 Thanks <br><br>

  Myskillhub <br>
  07065907948 <br>
  itaforfrancis@gmail.com<br>
</p>
</body>
</html>