<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
 <!-- breadcrum start -->

<section id="breadcrum">
  <div class="container">
      <?php echo $__env->make('master.remainder', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
</section>
        <!-- breadcrum ends -->

  <!-- Begin page content -->
<section id="main">
  <div class="container">
    <div class="row">
  <!-- Begin SIDE BAR -->
      <?php echo $__env->make('master.sideMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- END SIDE BAR -->

  <!-- Begin main content -->

       <div class="col-md-9">

<?php if(count($websiteProofs) > 0): ?>
  <!-- Non sliddable images -->
<div class="card-columns">
 <?php $__currentLoopData = $websiteProofs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $object): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card">
  <a href="https://<?php echo e($object->url); ?>"> <p><?php echo e($object->url); ?></p></a> 

    <div class="card-body">
      <a href="<?php echo e(url('deleteWebsiteProof',[$object->id])); ?>"
  onclick="return confirm('Are you sure you want to delete this project?')">
    <button type="button" class="btn  btn-danger">Delete</button> 
    </a>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php else: ?>
 <h4>No Website proof found</h4>
</div><!-- End main content -->
<?php endif; ?>


</div>
  </div>
</section>
    <!-- end page content -->






  
    
 
  

    <!-- end page content -->






<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>