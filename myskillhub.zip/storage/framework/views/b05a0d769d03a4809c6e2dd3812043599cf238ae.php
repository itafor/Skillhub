<?php $__env->startSection('content'); ?>
<?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

 <!-- breadcrum start -->

<section id="breadcrum">
  <div class="container">
      <?php echo $__env->make('master.remainder', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
</section>
        <!-- breadcrum ends -->

  <!-- Begin page content -->
<section id="main">
  <div class="container">
    <div class="row">
  <!-- Begin SIDE BAR -->
      <?php echo $__env->make('master.sideMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- END SIDE BAR -->

  <!-- Begin main content -->

       <div class="col-md-9">

<div class="card">
           <h5 class="card-header main-color-bg" style="color: #fff;">CV</h5>
        <div class="card-body">

        
      <!--POST SKILL FORM STARTS-->
<form  action="<?php echo e(route('addCV')); ?>" method="POST" enctype="multipart/form-data">
  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
  <div class="form-group row">
     <div class="input-group mb-3 col-md-6">
      <input type="file" class="form-control" name="cv" required="">
      <div class="input-group-append">
        <button class="btn btn-primary" type="submit">Save CV</button>
      </div>
    </div>
    <div class="col-md-3">
      <?php if($users->mycv): ?>
      <p><i class="fa fa-download info"></i><a href="/upload/<?php echo e($users->mycv); ?>" download="<?php echo e($users->mycv); ?>">My CV</a> </p>
      <?php endif; ?>
    </div>
    </div>
</form>

</div>
</div>


        
 
      </div><!-- End main content -->

    </div>
  </div>
</section>
    <!-- end page content -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>