<?php $__env->startSection('content'); ?>
<?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
 <!-- breadcrum start -->

<section id="breadcrum">
  <div class="container">
    <ol class="breadcrum">
      <a href="">Dashboard / Applicants</a>
    </ol>
  </div>
</section>
        <!-- breadcrum ends -->

  <!-- Begin page content -->
<section id="main">
  <div class="container">
    <div class="row">

  <!-- Begin main content -->
       <div class="col-md-12">
        <!-- site overview -->

           <div class="card">
            <h5 class="card-header main-color-bg" style="color: #fff;">Do you need  <?php echo e($userSex->sex == 'Male' ? 'his' : 'her'); ?> service? Contact us on 098975642  
  OR

  <div class="hireMe btn btn-primary"><a href="#" "><?php echo e($userSex->status == 'Available'?  $userSex->sex == 'Male' ? 'Employ him' : 'Employ her'  : 'EMPLOYED'); ?> </a> </div>
           </h5>
        <div class="card-body">
              
<div class="col-md-12 pull-left" >
 <?php if(count($checkvideoProofs) > 0): ?>
 <h5 class="card-header main-color-bg" style="color: #fff;">
           <?php echo e(count($checkvideoProofs)); ?> Video Proofs</h5>
 <?php $__currentLoopData = $checkvideoProofs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $object): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="card">
<h4><?php echo e($object->name); ?></h4>
<div class="card-body">
      <video id="my-video" class="video-js" controls preload="auto" width="800" height="400" data-setup="{}">
     <source src="/upload/<?php echo e($object->video); ?>" type='video/MP4'>
    <source src="/upload/<?php echo e($object->video); ?>" type="video/ogg">
       <source src="/upload/<?php echo e($object->video); ?>" type="video/avi">
 </video>
    
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php else: ?>
 <h4>No image found</h4>
</div><!-- End main content -->
<?php endif; ?>





        </div>
</div>
        
      </div><!-- End main content -->




</div>

    </div>
  
</section>
    <!-- end page content -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>