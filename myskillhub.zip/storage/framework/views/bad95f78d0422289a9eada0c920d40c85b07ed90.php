<ul class="breadcrum col-md-12">

<!-- side menu end -->


<a href="/admindashboard" style="width: 100px; height:70px; font-size: 20px; border-radius: 5px;  color: #ffffff;">Home</a>
<small class="offset-6">
	<?php if(auth::user()->role == 'Applicant'): ?>
<small style="font-size: 16px;">Status: <?php echo e(auth::user()->status); ?> </small>
 <a href="/editProfile"><li class="fa fa-pencil"></li></a>
	<?php endif; ?>
	 </small>
 </ul>
