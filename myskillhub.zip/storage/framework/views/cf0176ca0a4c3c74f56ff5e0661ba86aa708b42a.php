<?php $__env->startSection('content'); ?>
<?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
 <!-- breadcrum start -->

<section id="breadcrum">
  <div class="container">
      <?php echo $__env->make('master.remainder', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
</section>
        <!-- breadcrum ends -->

  <!-- Begin page content -->
<section id="main">
  <div class="container">
    <div class="row">
  <!-- Begin SIDE BAR -->
      <?php echo $__env->make('master.sideMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- END SIDE BAR -->

  <!-- Begin main content -->
<div class="col-md-9">
 <?php if(count($videoProofs) > 0): ?>
 <h5 class="card-header main-color-bg" style="color: #fff;">
           <?php echo e(count($videoProofs)); ?> Video Proofs</h5>
 <?php $__currentLoopData = $videoProofs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $object): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="card">
<h4><?php echo e($object->name); ?></h4>
<div class="card-body">
      <video id="my-video" class="video-js" controls preload="auto" width="800" height="400" data-setup="{}">
     <source src="/upload/<?php echo e($object->video); ?>" type='video/MP4'>
    <source src="/upload/<?php echo e($object->video); ?>" type="video/ogg">
       <source src="/upload/<?php echo e($object->video); ?>" type="video/avi">
 </video>
    
    <a href="<?php echo e(url('deleteImageProof',[$object->id])); ?>"
  onclick="return confirm('Are you sure you want to delete this video?')">
    <button type="button" class="btn  btn-danger">Delete</button> 
    </a>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php else: ?>
 <h4>No Video found</h4>
</div><!-- End main content -->
<?php endif; ?>


</div>
  </div>
</section>
    <!-- end page content -->






  
    
 
  


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>