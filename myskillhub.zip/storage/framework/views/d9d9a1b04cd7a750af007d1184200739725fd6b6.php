<?php $__env->startSection('content'); ?>
<?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

 <!-- breadcrum start -->
<section id="breadcrum">
  <div class="container">
      <?php echo $__env->make('master.remainder', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
</section>
        <!-- breadcrum ends -->

  <!-- Begin page content -->
<section id="main">
  <div class="container">
    <div class="row">
  <!-- Begin SIDE BAR -->
      <?php echo $__env->make('master.sideMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- END SIDE BAR -->

  <!-- Begin main content -->
       <div class="col-md-9">
                   <div id="message"></div>
      
 <div class="card">
           <h5 class="card-header main-color-bg" style="color: #fff;">All Employers: <?php echo e(count($allEmployers)); ?></h5>
        <div class="card-body">
                  <?php if(count($allEmployers) > 0): ?>
               <table class="table table-striped table-hover table-responsive table-bordered"  >
                 <tr>
                   <th>REG.DATE</th>
                   <th>NAME</th>
                   <th>GENDER</th>
                   <th>PHONE</th>
                   <th>EMAIL</th>
                   <th>VIEW MORE</th>
                   <th>DELETE</th>
                 </tr>
                  <?php $__currentLoopData = $allEmployers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allEmployer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                 <tr>
                  <td><?php echo e(Carbon\carbon::createFromTimestamp(strtotime($allEmployer->created_at))->diffForHumans()); ?></td>
                   <td><?php echo e($allEmployer->name); ?></td>
                   <td><?php echo e($allEmployer->sex); ?></td>
                   <td><?php echo e($allEmployer->phone); ?></td>
                   <td><?php echo e($allEmployer->email); ?></td>
                   

              <td> <a href="viewEmployer/<?php echo e($allEmployer->id); ?>" class="text-primary"><i class="fa fa-eye"></i> Details</a></td>
              <td> <a href="deleteEmployer/<?php echo e($allEmployer->id); ?>" class="text-danger" onclick="return confirm('You are about to delete the selected Employer, are you sure?')"><i class="fa fa-remove"></i></a></td>

                 
             
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   <?php else: ?>
                   <h4>No employer Found</h4>
                   <?php endif; ?>
                 </tr>
               </table> 

        </div>
</div>  <!-- Latest Users ends-->

      </div><!-- End main content -->

    </div>
  </div>
</section>
    <!-- end page content -->

<script type="text/javascript">
  //Ananimious self invoking function
  (function() {
    
     // declare variables and objects properties
    let pending = document.getElementById('Pending');

    let approve = document.getElementById('Approved');

    
    pending.style.color = 'Brown';
    approve.style.color = 'Green';

    
   
  }());
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>