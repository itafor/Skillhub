<?php $__env->startSection('content'); ?>
<?php echo $__env->make('master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

 <!-- breadcrum start -->
<section id="breadcrum">
  <div class="container">
      <?php echo $__env->make('master.remainder', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
</section>
        <!-- breadcrum ends -->

  <!-- Begin page content -->
<section id="main">
  <div class="container">
    <div class="row">
  <!-- Begin SIDE BAR -->
      <?php echo $__env->make('master.sideMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- END SIDE BAR -->

  <!-- Begin main content -->
       <div class="col-md-9">
                   <div id="message"></div>
      
 <div class="card">
           <h5 class="card-header main-color-bg" style="color: #fff;">SHARED JOBS</h5>
        <div class="card-body">
                  <?php if(count($sharedjobs) > 0): ?>
               <table class="table table-striped table-hover table-responsive" >
                 <tr>
                   <th>Company</th>
                   <th>Job Title</th>
                   <th>Date Posted</th>
                   <?php if(auth::user()->role == 'Applicant'): ?>
                   <th>View & Apply</th>
                   <?php endif; ?>
                   <?php if(auth::user()->role == 'Admin'): ?>
                   <th>ACTION</th>
                   <?php endif; ?>
                 </tr>
                  <?php $__currentLoopData = $sharedjobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                 <tr>
                   <td><?php echo e($req->compName); ?></td>
                   <td><?php echo e($req->jobTitle); ?></td>
                  <td><?php echo e(Carbon\carbon::createFromTimestamp(strtotime($req->created_at))->diffForHumans()); ?></td>
                  <?php if(auth::user()->role == 'Applicant'): ?>
              <td> <a href="viewSpecificEmpReq/<?php echo e($req->job_id); ?>"><i class="fa fa-eye text-primary"></i> Apply</a></td>
                   <?php endif; ?>
              
              <?php if(auth::user()->role == 'Admin'): ?>
              <td> <a href="deleteSharedjob/<?php echo e($req->job_id); ?>" onclick="return confirm('Are you sure you want delete this sharedjob?')"><i class="fa fa-remove text-primary"></i></a></td>
                   <?php endif; ?>

                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                   <?php else: ?>
                   <h4>No job found</h4>
                   <?php endif; ?>
                 </tr>
               </table> 
               <?php echo e($sharedjobs->links()); ?>

        </div>
</div>  <!-- Latest Users ends-->
      </div><!-- End main content -->

    </div>
  </div>
</section>
    <!-- end page content -->

<script type="text/javascript">
  //Ananimious self invoking function
  (function() {
    
     // declare variables and objects properties
    let pending = document.getElementById('Pending');

    let approve = document.getElementById('Approved');

    
    pending.style.color = 'Brown';
    approve.style.color = 'Green';

    
   
  }());
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>