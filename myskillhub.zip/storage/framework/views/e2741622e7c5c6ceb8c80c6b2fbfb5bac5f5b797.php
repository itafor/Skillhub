
<header id="header" >
        <div class="container"> 
          <div class="row">
            <div class="col-md-4 offset-4" style="margin-top:20px;">
            <?php if(auth::user()): ?>
            <span  id="welcomeUser" >Welcome <?php echo e(auth::user()->name); ?> (<?php echo e(auth::user()->role); ?>)</span>
            <?php endif; ?>
        
            </div>
          </div>
        </div>
    </header>