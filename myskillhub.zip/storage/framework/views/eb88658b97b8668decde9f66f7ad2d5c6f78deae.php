<?php $__env->startSection('content'); ?>
<div id="showcase">
<div class="section-main container">
<h3 class="text-dark welcomeMessage">Showcase your skills (what you can do better) and get your dream job</h3>
 
  <a href="<?php echo e(route('register')); ?>" class="btn btn-primary mb">Get Started</a>

 <h2 class="text-dark">Search Job seekers by Skills or Location</h2>
          <div class="row">
            <div class="col-md-12">
             <div class="col-md-6 pull-left">
              <form action="<?php echo e(route('searchskill')); ?>" method="post" id="searchSkillForm"> 
               <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                   <div class="input-group col-md-8 searchitem">
                      <input class="form-control py-2" type="text" name="searchskill" placeholder="Search by skills"  id="searchskill" autocomplete="off">
                      <div id="skillList"></div>
                        <span class="input-group-append">
                           <button class="btn btn-outline-secondary" type="submit">
                            <i class="fa fa-search">  </i>
                         </button>
                    </span>
                 </div>
          </form>
    </div>

<div class="col-md-6 pull-right ">
  <form action="<?php echo e(route('searchlocation')); ?>" method="post" id="searchLocationForm"> 
      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
          <div class="input-group col-md-8 searchitem">
              <input class="form-control py-2" type="text" name="searchlocation" placeholder="Search by location"  id="searchlocation" autocomplete="off">
  <div id="locationList"></div>
                  <span class="input-group-append">
                   <button class="btn btn-outline-secondary" type="submit">
                       <i class="fa fa-search">  </i>
                    </button>
                   </span>
                </div>
          </form>
      </div>               
  </div>
</div>
   </div><!--show end-->
</div><!--container end-->
 <!-- breadcrum start -->
   


<?php if(Auth::user()): ?>
<section id="breadcrum">
  <div class="container">
      
  </div>
</section>
<?php endif; ?>
<section id="main" class="text-center" >
  <!-- <div class="container"> -->
    <div class="row applicantsList" >
  <!-- Begin main content -->
<?php if(count($users) > 0): ?>
<div class="card-columns" >

 <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $object): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <div class="card text-center">
    <img class="card-img-top" src="/upload/<?php echo e($object->photo == '' ? 'female.png' : $object->photo); ?>">
    <div class="card-body">
       <span style="font-family: roboto; font-size: 20px;"><?php echo e($object->name); ?></span><br>
 <ul>  
<?php $userId = $object->id; 
     $cryptId = Crypt::encrypt($userId);       
?>
  <li> <a href="/jobseekerinfo/<?php echo e($cryptId); ?>" class="text text-danger" style="margin-left: -60px;">View Detail <i class="fa fa-arrow-right"></i></a> </li>
 
      <span style="margin-left: -20px;">Status: <b><?php echo e($object->status == 'Available'? 'Available' : 'Hired'); ?></b></span><br>
      </ul>
  <div class="hireMe btn btn-primary btn-sm"><a href="/requestUser/<?php echo e($cryptId); ?>"><?php echo e($object->status == 'Available'? 'HIRE ME' : 'HIRED'); ?> </a>
   </div>
    </div>
  </div>
  
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<!-- </div> -->
<?php else: ?>
<h4>Nothing matched your search</h4>
<?php endif; ?>
<span class="pagination"><?php echo e($users->links()); ?></span>
  </div>

</section>
    <!-- end page content -->
<?php echo $__env->make('master.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.firstNavBar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>