
<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
      <a class="navbar-brand" href="<?php echo e(url('/')); ?>" class="logo">SKILL HUB</a>

      <!-- <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button> -->
      
       <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav mr-auto offset-10" >
            
            <?php if(!auth::check()): ?>
          <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('register')); ?>">Signup</a>
            </li>
            <?php endif; ?>
          </ul>
         </div> 


         <ul class="navbar-nav navbar-right mobileview">
            <!-- usermenu start MObile view -->
          <?php if(auth::check()): ?>
  <div class="dropdown" style="margin-left: 100px;">
      <span>
       <img  src="/upload/<?php echo e(auth::user()->photo == '' ? 'female.png' : auth::user()->photo); ?>" style="width: 40px; height: 40px; border-radius: 50%; border:1px solid #fff; margin-right: 50px">
    </span>
     <div class="dropdown-content" style="margin-left: -100px; border-radius: 20px; padding-left: -80px;">
    
   
     <?php if(auth::user()->role == 'Applicant'): ?>
  <a href="<?php echo e(url('add-skill')); ?>"  class="dropdown-item" ><i class="fa fa-plus"></i> Add skill</a> 
          <?php endif; ?>
       <a href="/my-profile/<?php echo e(auth::user()->id); ?>"  class="dropdown-item" ><i class="fa fa-user"></i> My Profile</a> 
   
        <a class="dropdown-item" href="<?php echo e(url('editProfile')); ?>"><i class="fa fa-pencil"></i> Edit Profile</a>
       <a class="dropdown-item" href="<?php echo e(url('profilePicture')); ?>"><i class="fa fa-list-alt"></i> Profile Picture</a>
        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                  document.getElementById('logout-form').submit();">
                 <i class="fa fa-list-alt"></i> <?php echo e(__('Logout')); ?></a>
              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
              </form>
    </div>
</div>
</ul>
      <?php endif; ?>

   <div>
           <ul class="navbar-nav navbar-right desktopView">
              <?php if(auth()->guard()->guest()): ?>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('register')); ?>">Signup</a>
            </li>
            <?php else: ?>
            <!-- usermenu start -->
            <li class="nav-item">
              <!-- <span  style="margin-right: 20px; color:#ffffff"> <?php echo e(auth::user()->name); ?> (<?php echo e(auth::user()->role); ?>)</span> -->
            </li>
            <li class="nav-item">
<div class="dropdown create">
           <span class="dropdown-toggle" type="text" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
  <img  src="/upload/<?php echo e(auth::user()->photo == '' ? 'female.png' : auth::user()->photo); ?>" style="width: 40px; height: 40px; border-radius: 50%; border:1px solid #fff; margin-right: 50px">
        </span>
          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
         
          <?php if(auth::user()->role == 'Applicant'): ?>
  <a href="<?php echo e(url('add-skill')); ?>"  class="dropdown-item" ><i class="fa fa-plus"></i> Add skill</a> 
          <?php endif; ?>
  <?php if(auth::user()->role == 'Applicant'): ?>
   <a href="/my-profile/<?php echo e(auth::user()->id); ?>"  class="dropdown-item" ><i class="fa fa-user"></i> My Profile</a> 
 <?php endif; ?>
     <a class="dropdown-item" href="<?php echo e(url('editProfile')); ?>"><i class="fa fa-pencil"></i> Edit Profile</a>
         
         <a class="dropdown-item" href="<?php echo e(url('profilePicture')); ?>"><i class="fa fa-list-alt"></i> Profile Picture</a>
      </div>
  </div>
            </li> <!-- usermenu end -->
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                  document.getElementById('logout-form').submit();">
                 <?php echo e(__('Logout')); ?></a>
              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
              </form>
            </li>
          </ul>
           <?php endif; ?> 
        </div>
    </nav>
